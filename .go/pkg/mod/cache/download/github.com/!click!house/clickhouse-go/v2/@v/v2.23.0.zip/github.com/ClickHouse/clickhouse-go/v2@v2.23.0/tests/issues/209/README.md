Run
===

```sh
siege -t60m -c200  http://127.0.0.1:8080/test
```